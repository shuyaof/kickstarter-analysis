# Kickstarting with Excel

### Purpose
## Overview of Project
Utilize excel functions like conditional formatting, if formula, pivot table and charts, vlookup function to analysis data and draw conclusioins.

## Analysis and Challenges
When I was doing deliverable 2.8, my chart doesn't look like the example. Then i reached out to TA. We found out I forgot to filter out "play" in the countifs.

### Analysis of Outcomes Based on Launch Date
### Analysis of Outcomes Based on Goals
### Challenges and Difficulties Encountered

## Results
- What are two conclusions you can draw about the Outcomes based on Launch Date?
1.May has the most successful launches.
2.The trend for the failed launches is similar to successful ones except December.
- What can you conclude about the Outcomes based on Goals?
There are no canceled fundarasing event for the goal between $1,000 and $50,000 from 2009 to 2017.
- What are some limitations of this dataset?
I'm not sure if the average donation is converted into the same currency. We may not easily comparing numbers without converting.
- What are some other possible tables and/or graphs that we could create?
We can create graphs to show different fundraising goals comparing different countries.