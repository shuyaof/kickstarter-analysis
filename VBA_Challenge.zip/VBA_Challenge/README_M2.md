
1.Overview of Project
##The purpose and background are well defined (2 pt).
###Create an automatic way with a click of a button to analyze stock volume and return percentage.
2.Results
##The analysis is well described with screenshots and code (4 pt).
3.Summary
##There is a detailed statement on the advantages and disadvantages of refactoring code in general (3 pt).
###In 2017, the only stock with a negative return% is TERP. In 2018, the stock market is doing worse compared to the previous year.
##There is a detailed statement on the advantages and disadvantages of the original and refactored VBA script (3 pt).
#Submission
##Overview of Project: Explain the purpose of this analysis.
##Results: Using images and examples of your code, compare the stock performance between 2017 and 2018, as well as the execution times of the original script and the refactored script.
### 2017 data analysis ran faster than 2018.
##Summary: In a summary statement, address the following questions.
##What are the advantages or disadvantages of refactoring code?
###The refactored codes are shorter, but the rewritten version runs faster. 
#How do these pros and cons apply to refactoring the original VBA script?
###The rewritten codes makes it run faster because added if statement, which the codes dont have to go through all the lines. 