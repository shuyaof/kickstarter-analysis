1. Overview of Project
- The purpose of this analysis is to create an automatic way with a click of a button and enter the year to show stock volume and return percentage.
2. Results
- In 2017, the only stock with a negative return% is TERP. In 2018, the stock market is doing worse compared to the previous year.
- The speed of the refractored codes are faster than the original.
3. Summary
- 1. The original codes are shorter, but the refractored version is faster.  
- 2. The rewritten codes makes it run faster because added if statement, which the codes dont have to go through all the lines. 